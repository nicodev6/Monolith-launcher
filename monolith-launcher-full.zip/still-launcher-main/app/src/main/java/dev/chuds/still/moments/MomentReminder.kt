package dev.chuds.still.moments

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import dev.chuds.still.MainActivity
import java.util.Calendar

private const val PREFS_NAME = "monolith_moment_reminder"
private const val KEY_ENABLED = "enabled"
private const val KEY_HOUR = "hour"
private const val KEY_MINUTE = "minute"
private const val REMINDER_REQUEST_CODE = 7314
private const val CHANNEL_ID = "one_moment_daily"

data class MomentReminderSettings(
    val enabled: Boolean = false,
    val hour: Int = 20,
    val minute: Int = 0,
)

class MomentReminderPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun get(): MomentReminderSettings = MomentReminderSettings(
        enabled = prefs.getBoolean(KEY_ENABLED, false),
        hour = prefs.getInt(KEY_HOUR, 20).coerceIn(0, 23),
        minute = prefs.getInt(KEY_MINUTE, 0).coerceIn(0, 59),
    )

    fun setEnabled(enabled: Boolean): MomentReminderSettings {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()
        return get()
    }

    fun setTime(hour: Int, minute: Int): MomentReminderSettings {
        prefs.edit()
            .putInt(KEY_HOUR, hour.coerceIn(0, 23))
            .putInt(KEY_MINUTE, minute.coerceIn(0, 59))
            .apply()
        return get()
    }
}

object MomentReminderScheduler {
    fun sync(context: Context, settings: MomentReminderSettings) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = reminderPendingIntent(context)
        if (!settings.enabled) {
            alarmManager.cancel(pendingIntent)
            return
        }
        val firstTrigger = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, settings.hour)
            set(Calendar.MINUTE, settings.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        // Use a one-shot inexact alarm and schedule the next local-calendar day after it fires.
        // That keeps the selected wall-clock time stable across daylight-saving changes.
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            firstTrigger,
            pendingIntent,
        )
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(reminderPendingIntent(context))
    }

    private fun reminderPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MomentReminderReceiver::class.java).setAction("dev.chuds.still.MOMENT_REMINDER")
        return PendingIntent.getBroadcast(
            context,
            REMINDER_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}

class MomentReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED ||
            intent?.action == Intent.ACTION_TIME_CHANGED ||
            intent?.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent?.action == Intent.ACTION_DATE_CHANGED ||
            intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val settings = MomentReminderPreferences(context).get()
            MomentReminderScheduler.sync(context, settings)
            return
        }
        if (intent?.action != "dev.chuds.still.MOMENT_REMINDER") return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Codzienny moment",
                    NotificationManager.IMPORTANCE_DEFAULT,
                ).apply { description = "Przypomnienie o zapisaniu jednego ważnego momentu dnia" },
            )
        }

        val openApp = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            context, REMINDER_REQUEST_CODE, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = android.app.Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("Jeden Moment")
            .setContentText("Co dzisiaj było dla Ciebie ważne?")
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()

        // Android 13+ requires the runtime notification permission. If it is not granted,
        // notify() is safely ignored by the platform and the reminder remains scheduled.
        try {
            manager.notify(REMINDER_REQUEST_CODE, notification)
        } catch (_: SecurityException) {
            // Permission was denied or revoked; do not crash the receiver.
        }
        // Chain the next local-time reminder. This still runs when notification permission
        // is denied, so granting permission later does not require recreating the alarm.
        MomentReminderScheduler.sync(context, MomentReminderPreferences(context).get())
    }
}
