package dev.chuds.still.moments

import android.Manifest
import android.net.Uri
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chuds.still.data.IntentJournalExporter
import dev.chuds.still.ui.theme.StillColors
import dev.chuds.still.ui.theme.StillTypography
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Cream = Color(0xFFF0D8B8)
private val Surface = Color(0xFF101010)
private val Border = Color(0xFF343434)
private val Polish = Locale("pl", "PL")

@Composable
fun MomentDashboardScreen(
    entries: List<MomentEntry>,
    onBack: () -> Unit,
    onNewEntry: () -> Unit,
    onEditEntry: (LocalDate) -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenReminder: () -> Unit,
) {
    val today = LocalDate.now()
    val context = LocalContext.current
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri: Uri? ->
        if (uri != null) {
            val markdown = buildString {
                appendLine("# Jeden Moment")
                appendLine()
                appendLine("Prywatny dziennik codziennych momentów.")
                appendLine()
                entries.sortedByDescending { it.day }.forEach { entry ->
                    appendLine("## ${entry.day.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Polish))}")
                    appendLine()
                    appendLine(entry.text)
                    appendLine()
                }
            }
            IntentJournalExporter.writeToUri(context, uri, markdown)
        }
    }
    val todayEntry = entries.firstOrNull { it.day == today }
    val streak = currentStreak(entries, today)
    val recent = entries.take(5)

    MomentPage {
        Header("JEDEN MOMENT", "Zatrzymaj to, co ulotne.", onBack)
        Spacer(Modifier.height(22.dp))
        Panel {
            Text("DZISIAJ", style = StillTypography.Kicker, color = Cream)
            Spacer(Modifier.height(10.dp))
            Text(
                if (todayEntry == null) "Co dzisiaj było dla Ciebie ważne?" else "Dzisiejszy moment został zapisany.",
                color = StillColors.SoftWhite,
                fontSize = 21.sp,
                lineHeight = 28.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(14.dp))
            if (todayEntry != null) {
                Text(todayEntry.text, color = StillColors.MutedWhite, style = StillTypography.SecondaryMenu)
                Spacer(Modifier.height(14.dp))
            }
            CreamAction(
                title = if (todayEntry == null) "＋  Zapisz moment" else "Edytuj dzisiejszy moment",
                onClick = { onEditEntry(today) },
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("✦  Seria zapisu", color = StillColors.Gray, style = StillTypography.Caption)
                Spacer(Modifier.weight(1f))
                Text("$streak dni", color = Cream, style = StillTypography.SecondaryMenu)
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("TWOJE MOMENTY", style = StillTypography.Kicker, color = StillColors.DimGray)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallAction("Kalendarz", "▦", onOpenCalendar, Modifier.weight(1f))
            SmallAction("Statystyki", "◷", onOpenStats, Modifier.weight(1f))
            SmallAction("Przypomnienie", "♧", onOpenReminder, Modifier.weight(1f))
        }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("OSTATNIE WPISY", style = StillTypography.Kicker, color = StillColors.DimGray, modifier = Modifier.weight(1f))
            Text("＋ Nowy", style = StillTypography.Caption, color = Cream, modifier = Modifier.clickable(onClick = onNewEntry).padding(end = 12.dp))
            Text("Wszystkie  ›", style = StillTypography.Caption, color = StillColors.MutedWhite, modifier = Modifier.clickable(onClick = onOpenCalendar))
        }
        Spacer(Modifier.height(8.dp))
        if (recent.isEmpty()) {
            Text("Tutaj pojawią się zapisane przez Ciebie chwile.", color = StillColors.Gray, style = StillTypography.Date)
        } else {
            recent.forEach { entry ->
                Column(
                    modifier = Modifier.fillMaxWidth().clickable { onEditEntry(entry.day) }.padding(vertical = 10.dp),
                ) {
                    Text(entry.day.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Polish)), color = Cream, style = StillTypography.Caption)
                    Spacer(Modifier.height(4.dp))
                    Text(entry.text, color = StillColors.MutedWhite, style = StillTypography.SecondaryMenu, maxLines = 2)
                }
                DividerLine()
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Eksportuj wszystkie wpisy  ↗",
                color = Cream,
                style = StillTypography.Caption,
                modifier = Modifier.clickable { exportLauncher.launch("jeden-moment.md") }.padding(vertical = 10.dp),
            )
        }
    }
}

@Composable
fun MomentEditorScreen(
    date: LocalDate,
    existing: MomentEntry?,
    onBack: () -> Unit,
    onSave: (String) -> Unit,
    onDelete: () -> Unit,
) {
    var text by remember(date, existing?.updatedAt) { mutableStateOf(existing?.text.orEmpty()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val dateLabel = date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Polish))

    MomentPage {
        Header("JEDEN MOMENT", dateLabel.replaceFirstChar { it.uppercase(Polish) }, onBack)
        Spacer(Modifier.height(36.dp))
        Text("Co dzisiaj było dla Ciebie ważne?", color = StillColors.SoftWhite, fontSize = 25.sp, lineHeight = 32.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Text("Nie musi być wielkie. Wystarczy, że było Twoje.", color = StillColors.Gray, style = StillTypography.Date)
        Spacer(Modifier.height(24.dp))

        Column(
            modifier = Modifier.fillMaxWidth()
                .border(1.dp, Border, RoundedCornerShape(18.dp))
                .background(Surface, RoundedCornerShape(18.dp))
                .padding(16.dp),
        ) {
            Box(Modifier.fillMaxWidth().height(180.dp)) {
                if (text.isEmpty()) {
                    Text("Zapisz swój moment...", color = StillColors.DimGray, style = StillTypography.SecondaryMenu)
                }
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.take(MomentRepository.MAX_MOMENT_LENGTH) },
                    modifier = Modifier.fillMaxSize(),
                    textStyle = StillTypography.SecondaryMenu.copy(color = StillColors.SoftWhite, lineHeight = 27.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Cream),
                )
            }
            Text("${text.length}/${MomentRepository.MAX_MOMENT_LENGTH}", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End, color = StillColors.DimGray, style = StillTypography.Caption)
        }
        Spacer(Modifier.height(18.dp))
        CreamAction("Zapisz", onClick = { onSave(text.trim()) }, enabled = text.isNotBlank())
        if (existing != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                if (confirmDelete) "Potwierdź usunięcie wpisu" else "Usuń wpis",
                color = if (confirmDelete) Color(0xFFE3A19A) else StillColors.DimGray,
                style = StillTypography.Caption,
                modifier = Modifier.fillMaxWidth().clickable {
                    if (confirmDelete) onDelete() else confirmDelete = true
                }.padding(vertical = 12.dp),
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun MomentCalendarScreen(
    entries: List<MomentEntry>,
    onBack: () -> Unit,
    onSelectDate: (LocalDate) -> Unit,
) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    val entryDays = remember(entries) { entries.map { it.day }.toSet() }
    val firstOffset = month.atDay(1).dayOfWeek.value - DayOfWeek.MONDAY.value
    val totalCells = ((firstOffset + month.lengthOfMonth() + 6) / 7) * 7
    val days = (0 until totalCells).map { index ->
        val number = index - firstOffset + 1
        if (number in 1..month.lengthOfMonth()) month.atDay(number) else null
    }

    MomentPage {
        Header("KALENDARZ", "Twoje zapisane dni.", onBack)
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", color = StillColors.SoftWhite, fontSize = 32.sp, modifier = Modifier.clickable { month = month.minusMonths(1) }.padding(horizontal = 12.dp))
            Text(month.format(DateTimeFormatter.ofPattern("LLLL yyyy", Polish)).replaceFirstChar { it.uppercase(Polish) }, color = StillColors.SoftWhite, style = StillTypography.SecondaryMenu, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Text("›", color = StillColors.SoftWhite, fontSize = 32.sp, modifier = Modifier.clickable { month = month.plusMonths(1) }.padding(horizontal = 12.dp))
        }
        Spacer(Modifier.height(14.dp))
        Row {
            listOf("Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd").forEach {
                Text(it, modifier = Modifier.weight(1f), color = StillColors.DimGray, textAlign = TextAlign.Center, style = StillTypography.Caption)
            }
        }
        Spacer(Modifier.height(8.dp))
        days.chunked(7).forEach { week ->
            Row {
                week.forEach { day ->
                    Box(
                        modifier = Modifier.weight(1f).height(52.dp).padding(3.dp)
                            .then(if (day != null) Modifier.clickable { onSelectDate(day) } else Modifier),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (day != null) {
                            val hasEntry = day in entryDays
                            val isToday = day == LocalDate.now()
                            Box(
                                Modifier.size(38.dp)
                                    .background(
                                        when {
                                            hasEntry -> Cream
                                            isToday -> Color(0xFF29241F)
                                            else -> Color.Transparent
                                        }, CircleShape,
                                    ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(day.dayOfMonth.toString(), color = if (hasEntry) Color(0xFF17130F) else StillColors.SoftWhite, style = StillTypography.Small)
                            }
                            if (hasEntry) Text("•", color = Cream, fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomCenter))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).background(Cream, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text("Dzień z zapisanym momentem", color = StillColors.Gray, style = StillTypography.Caption)
        }
        Spacer(Modifier.height(20.dp))
        entries.filter { YearMonth.from(it.day) == month }.forEach { entry ->
            Column(Modifier.fillMaxWidth().clickable { onSelectDate(entry.day) }.padding(vertical = 10.dp)) {
                Text(entry.day.format(DateTimeFormatter.ofPattern("d MMMM", Polish)), color = Cream, style = StillTypography.Caption)
                Spacer(Modifier.height(4.dp))
                Text(entry.text, color = StillColors.MutedWhite, style = StillTypography.SecondaryMenu, maxLines = 2)
            }
            DividerLine()
        }
    }
}

@Composable
fun MomentStatsScreen(entries: List<MomentEntry>, onBack: () -> Unit) {
    val today = LocalDate.now()
    val current = currentStreak(entries, today)
    val longest = longestStreak(entries)
    val monthCount = entries.count { YearMonth.from(it.day) == YearMonth.now() }
    MomentPage {
        Header("STATYSTYKI", "Małe chwile, które zostają.", onBack)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatPanel("${entries.size}", "zapisanych dni", Modifier.weight(1f))
            StatPanel("$current", "aktualna seria", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatPanel("$longest", "najdłuższa seria", Modifier.weight(1f))
            StatPanel("$monthCount", "w tym miesiącu", Modifier.weight(1f))
        }
        Spacer(Modifier.height(24.dp))
        Text("REGULARNOŚĆ", style = StillTypography.Kicker, color = StillColors.DimGray)
        Spacer(Modifier.height(10.dp))
        Text(
            when {
                entries.isEmpty() -> "Pierwszy zapis może być początkiem pięknej kolekcji."
                current == 0 -> "Wróć dziś do małego rytuału. Nie musisz nadrabiać pominiętych dni."
                current == 1 -> "Masz jeden zapisany dzień. Jutro możesz przedłużyć tę serię."
                else -> "Zapisujesz ważne chwile już od $current dni z rzędu. Dobra robota."
            },
            color = StillColors.MutedWhite,
            style = StillTypography.SecondaryMenu,
        )
    }
}

@Composable
fun MomentReminderScreen(
    settings: MomentReminderSettings,
    onBack: () -> Unit,
    onSetEnabled: (Boolean) -> Unit,
    onSetTime: (Int, Int) -> Unit,
) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onSetEnabled(true)
    }
    val timeLabel = String.format(Locale.getDefault(), "%02d:%02d", settings.hour, settings.minute)

    MomentPage {
        Header("PRZYPOMNIENIE", "Codzienny moment tylko dla Ciebie.", onBack)
        Spacer(Modifier.height(24.dp))
        Panel {
            Text("CODZIENNE PRZYPOMNIENIE", style = StillTypography.Kicker, color = Cream)
            Spacer(Modifier.height(10.dp))
            Text("Niech telefon przypomni Ci, żeby na chwilę się zatrzymać.", color = StillColors.MutedWhite, style = StillTypography.SecondaryMenu)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Włącz przypomnienie", color = StillColors.SoftWhite, style = StillTypography.SecondaryMenu)
                    Text(if (settings.enabled) "Aktywne każdego dnia" else "Wyłączone", color = StillColors.Gray, style = StillTypography.Caption)
                }
                Text(
                    if (settings.enabled) "WŁ." else "WYŁ.",
                    color = if (settings.enabled) Cream else StillColors.Gray,
                    style = StillTypography.SecondaryMenu,
                    modifier = Modifier.clickable {
                        if (settings.enabled) {
                            onSetEnabled(false)
                        } else if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            onSetEnabled(true)
                        }
                    }.padding(8.dp),
                )
            }
            Spacer(Modifier.height(16.dp))
            DividerLine()
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Godzina", color = StillColors.Gray, style = StillTypography.Caption)
                    Text(timeLabel, color = StillColors.SoftWhite, fontSize = 34.sp)
                }
                Text("Zmień  ›", color = Cream, style = StillTypography.SecondaryMenu, modifier = Modifier.clickable {
                    TimePickerDialog(context, { _, hour, minute -> onSetTime(hour, minute) }, settings.hour, settings.minute, true).show()
                }.padding(8.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Powiadomienia wymagają zgody systemu Android. Godzina może zostać lekko przesunięta przez oszczędzanie baterii.", color = StillColors.DimGray, style = StillTypography.Caption)
    }
}

@Composable
private fun MomentPage(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(StillColors.OledBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 25.dp, vertical = 20.dp)
            .padding(bottom = 28.dp),
    ) { content() }
}

@Composable
private fun Header(title: String, subtitle: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.Top) {
        Text("‹", color = StillColors.SoftWhite, fontSize = 34.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp))
        Column {
            Text(title, color = StillColors.MutedWhite, style = StillTypography.Kicker)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = StillColors.Gray, style = StillTypography.Date)
        }
    }
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().border(1.dp, Border, RoundedCornerShape(20.dp))
            .background(Surface, RoundedCornerShape(20.dp)).padding(18.dp),
    ) { content() }
}

@Composable
private fun CreamAction(title: String, onClick: () -> Unit, enabled: Boolean = true) {
    Box(
        Modifier.fillMaxWidth().background(if (enabled) Cream else Color(0xFF6B6258), RoundedCornerShape(50.dp))
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) { Text(title, color = Color(0xFF17130F), fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun SmallAction(title: String, symbol: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Surface, RoundedCornerShape(15.dp)).border(1.dp, Border, RoundedCornerShape(15.dp))
            .clickable(onClick = onClick).padding(vertical = 13.dp, horizontal = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(symbol, color = Cream, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        Text(title, color = StillColors.MutedWhite, style = StillTypography.Caption, textAlign = TextAlign.Center)
    }
}

@Composable
private fun StatPanel(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Surface, RoundedCornerShape(18.dp)).border(1.dp, Border, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(value, color = Cream, fontSize = 34.sp, fontWeight = FontWeight.Light)
        Text(label, color = StillColors.Gray, style = StillTypography.Caption)
    }
}

@Composable
private fun DividerLine() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF262626)))
}

private fun currentStreak(entries: List<MomentEntry>, today: LocalDate): Int {
    val days = entries.map { it.day }.toSet()
    var cursor = if (today in days) today else today.minusDays(1)
    var count = 0
    while (cursor in days) {
        count++
        cursor = cursor.minusDays(1)
    }
    return count
}

private fun longestStreak(entries: List<MomentEntry>): Int {
    val days = entries.map { it.day }.distinct().sorted()
    if (days.isEmpty()) return 0
    var longest = 1
    var current = 1
    for (index in 1 until days.size) {
        if (days[index] == days[index - 1].plusDays(1)) current++ else current = 1
        if (current > longest) longest = current
    }
    return longest
}
