package dev.chuds.still.ui.home

import android.text.format.DateFormat
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chuds.still.data.ClockFormat
import dev.chuds.still.ui.components.StillMenuItem
import dev.chuds.still.ui.theme.StillColors
import dev.chuds.still.ui.theme.StillTypography
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

private val MomentCream = Color(0xFFF0D8B8)
private val CardSurface = Color(0xFF101010)

/**
 * Monolith-inspired home: oversized clock, a prominent reflection card and a compact
 * launcher list. The existing Still launcher actions/settings remain intact.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    uiState: HomeUiState,
    onLaunchSlot: (Int) -> Unit,
    onEditSlot: (Int) -> Unit,
    onOpenAllApps: () -> Unit,
    onOpenIntents: () -> Unit,
    onOpenMomentEditor: () -> Unit,
    onOpenMoments: () -> Unit,
    momentStreak: Int,
    todayHasMoment: Boolean,
    lastMomentDate: String?,
    modifier: Modifier = Modifier,
) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    val backgroundInteractionSource = remember { MutableInteractionSource() }
    val dateInteractionSource = remember { MutableInteractionSource() }
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1_000)
        }
    }

    val use24h = when (uiState.settings.clockFormat) {
        ClockFormat.Hours24 -> true
        ClockFormat.Hours12 -> false
        ClockFormat.Auto -> DateFormat.is24HourFormat(context)
    }
    val clockPattern = if (use24h) "HH:mm" else "h:mm"
    val clockFormatter = remember(clockPattern) {
        DateTimeFormatter.ofPattern(clockPattern, Locale.getDefault())
    }
    val dateFormatter = remember {
        DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StillColors.OledBlack)
            .combinedClickable(
                interactionSource = backgroundInteractionSource,
                indication = null,
                onClick = {},
                onLongClick = onOpenAllApps,
            )
            .systemBarsPadding()
            .padding(horizontal = 25.dp, vertical = 20.dp),
    ) {
        Text(
            text = "M O N O L I T H",
            style = StillTypography.Kicker,
            color = StillColors.MutedWhite,
            modifier = Modifier.padding(bottom = 18.dp),
        )

        Text(
            text = now.format(clockFormatter),
            style = StillTypography.Clock,
            color = StillColors.SoftWhite,
        )

        if (uiState.settings.showDate) {
            Text(
                text = now.format(dateFormatter).replaceFirstChar { it.uppercase(Locale.getDefault()) },
                style = StillTypography.Date,
                color = StillColors.MutedWhite,
                modifier = Modifier.clickable(
                    interactionSource = dateInteractionSource,
                    indication = null,
                    onClick = onOpenIntents,
                ),
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Subtle atmospheric mountain-like horizon, drawn with typography instead of
        // bundled wallpaper so the launcher stays lightweight and OLED-friendly.
        Row(
            modifier = Modifier.fillMaxWidth().height(42.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Bottom,
        ) {
            Text("◢", color = Color(0xFF262626), fontSize = 43.sp, lineHeight = 43.sp)
            Text("◢", color = Color(0xFF191919), fontSize = 33.sp, lineHeight = 33.sp)
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF343434), RoundedCornerShape(22.dp))
                .background(CardSurface, RoundedCornerShape(22.dp))
                .padding(horizontal = 19.dp, vertical = 17.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("◈", color = MomentCream, fontSize = 23.sp)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Jeden Moment",
                    color = StillColors.SoftWhite,
                    style = StillTypography.SecondaryMenu,
                    modifier = Modifier.weight(1f),
                )
                Text("✦", color = MomentCream, fontSize = 17.sp)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Co dzisiaj było dla Ciebie ważne?",
                color = StillColors.SoftWhite,
                fontSize = 19.sp,
                lineHeight = 25.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(13.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MomentCream, RoundedCornerShape(50.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onOpenMomentEditor,
                    )
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (todayHasMoment) "＋  Edytuj dzisiejszy moment" else "＋  Zapisz moment", color = Color(0xFF17130F), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(13.dp))
            Row(
                modifier = Modifier.fillMaxWidth().clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onOpenMoments,
                ),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "◷  Ostatni wpis: ${lastMomentDate ?: "brak"}",
                    color = StillColors.Gray,
                    style = StillTypography.Caption,
                    modifier = Modifier.weight(1f),
                )
                Text("✦  $momentStreak dni   ›", color = MomentCream, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(15.dp))

        Text(
            "TWOJE APLIKACJE",
            color = StillColors.DimGray,
            style = StillTypography.Kicker,
            modifier = Modifier.padding(start = 3.dp, bottom = 5.dp),
        )

        uiState.homeSlots.forEach { resolved ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("○", color = StillColors.MutedWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 4.dp, end = 13.dp))
                StillMenuItem(
                    title = resolved.displayLabel.orEmpty(),
                    subtitle = if (resolved.slot.useFriction) "otwórz świadomie" else null,
                    onClick = { onLaunchSlot(resolved.slot.index) },
                    onLongClick = { onEditSlot(resolved.slot.index) },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        if (uiState.settings.showHomeHint) {
            Text(
                text = "przytrzymaj ekran, aby otworzyć wszystkie aplikacje",
                style = StillTypography.Caption,
                color = StillColors.DimGray,
                modifier = Modifier.padding(bottom = 4.dp),
            )
        }
    }
}
