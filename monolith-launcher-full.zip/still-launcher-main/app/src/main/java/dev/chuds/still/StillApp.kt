package dev.chuds.still

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import dev.chuds.still.data.AppRepository
import dev.chuds.still.data.ClockFormat
import dev.chuds.still.data.FontPreset
import dev.chuds.still.data.IntentJournalRepository
import dev.chuds.still.data.PreferencesRepository
import dev.chuds.still.ui.haptics.LocalHapticsEnabled
import dev.chuds.still.ui.theme.LocalStillTypography
import dev.chuds.still.ui.theme.stillTypographyFor
import dev.chuds.still.launcher.AppLauncher
import dev.chuds.still.launcher.DefaultSlotResolver
import dev.chuds.still.launcher.PackageScanner
import dev.chuds.still.launcher.SystemSettingsLocator
import dev.chuds.still.launcher.requiresDrawerFriction
import dev.chuds.still.ui.home.HomeScreen
import dev.chuds.still.ui.home.HomeViewModel
import dev.chuds.still.ui.home.SlotEditScreen
import dev.chuds.still.ui.home.SlotRenameScreen
import dev.chuds.still.ui.intents.IntentPromptScreen
import dev.chuds.still.ui.intents.IntentsScreen
import dev.chuds.still.ui.settings.AllAppsScreen
import dev.chuds.still.ui.settings.AppPickerScreen
import dev.chuds.still.ui.settings.DrawerExceptionsScreen
import dev.chuds.still.ui.settings.SettingsScreen
import dev.chuds.still.moments.MomentRepository
import dev.chuds.still.moments.MomentReminderPreferences
import dev.chuds.still.moments.MomentReminderScheduler
import dev.chuds.still.moments.MomentReminderSettings
import dev.chuds.still.moments.MomentDashboardScreen
import dev.chuds.still.moments.MomentEditorScreen
import dev.chuds.still.moments.MomentCalendarScreen
import dev.chuds.still.moments.MomentStatsScreen
import dev.chuds.still.moments.MomentReminderScreen
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Top-level Compose application shell.
 *
 * Hand-rolled router with a `returnTo` hint so flows started from Settings unwind to Settings
 * rather than Home. Intent prompt journals the typed text on Open before launching.
 */
@Composable
fun StillApp() {
    val appContext = LocalContext.current.applicationContext

    val preferencesRepository = remember(appContext) { PreferencesRepository(appContext) }
    val momentRepository = remember(appContext) { MomentRepository(appContext) }
    val reminderPreferences = remember(appContext) { MomentReminderPreferences(appContext) }
    val momentEntries by momentRepository.entries.collectAsStateWithLifecycle()
    var reminderSettings by remember { mutableStateOf(reminderPreferences.get()) }
    LaunchedEffect(reminderSettings) {
        MomentReminderScheduler.sync(appContext, reminderSettings)
    }
    val intentJournalRepository = remember(appContext) { IntentJournalRepository(appContext) }
    val appRepository = remember(appContext) {
        AppRepository(
            packageScanner = PackageScanner(appContext.packageManager),
            preferencesRepository = preferencesRepository,
            defaultSlotResolver = DefaultSlotResolver(appContext.packageManager),
        )
    }
    val appLauncher = remember(appContext) { AppLauncher(appContext) }
    val systemSettingsPackage = remember(appContext) {
        SystemSettingsLocator(appContext.packageManager).packageName
    }

    val homeViewModel: HomeViewModel = viewModel(
        factory = HomeViewModel.factory(
            appRepository = appRepository,
            appLauncher = appLauncher,
            intentJournalRepository = intentJournalRepository,
            systemSettingsPackage = systemSettingsPackage,
        ),
    )

    val uiState by homeViewModel.uiState.collectAsStateWithLifecycle()
    val intentEntries by homeViewModel.intentEntries.collectAsState()
    var route by remember { mutableStateOf<StillRoute>(StillRoute.Home) }

    BackHandler(enabled = route != StillRoute.Home) {
        route = route.backTarget()
    }

    fun launchSlot(slotIndex: Int) {
        val resolved = uiState.resolvedSlots.getOrNull(slotIndex)
        when {
            resolved == null || !resolved.isLaunchable -> Unit
            resolved.slot.useFriction -> {
                route = StillRoute.IntentPrompt(slotIndex)
            }
            else -> {
                homeViewModel.launchSlot(slotIndex)
            }
        }
    }

    val typographyValues = remember(uiState.settings.fontPreset) {
        stillTypographyFor(uiState.settings.fontPreset)
    }

    CompositionLocalProvider(
        LocalStillTypography provides typographyValues,
        LocalHapticsEnabled provides uiState.settings.hapticsEnabled,
    ) {
    when (val currentRoute = route) {
        StillRoute.Home -> HomeScreen(
            uiState = uiState,
            onLaunchSlot = ::launchSlot,
            onEditSlot = { index -> route = StillRoute.SlotEdit(index, ReturnTo.Home) },
            onOpenAllApps = {
                homeViewModel.refreshApps()
                route = StillRoute.AllApps
            },
            onOpenIntents = { route = StillRoute.Intents(ReturnTo.Home) },
            onOpenMomentEditor = { route = StillRoute.MomentEditor(LocalDate.now(), MomentReturnTo.Home) },
            onOpenMoments = { route = StillRoute.MomentDashboard },
            momentStreak = momentCurrentStreak(momentEntries),
            todayHasMoment = momentEntries.any { it.day == LocalDate.now() },
            lastMomentDate = momentEntries.firstOrNull()?.day?.format(
                DateTimeFormatter.ofPattern("EEE, d MMM", Locale("pl", "PL")),
            ),
        )

        StillRoute.AllApps -> AllAppsScreen(
            apps = uiState.apps,
            showAppIcons = uiState.settings.showAppIcons,
            onLaunchApp = { app ->
                if (requiresDrawerFriction(app, uiState.settings)) {
                    route = StillRoute.IntentPromptApp(
                        packageName = app.packageName,
                        className = app.className,
                        label = app.label,
                    )
                } else {
                    homeViewModel.launchApp(app)
                    route = StillRoute.Home
                }
            },
            onOpenStillSettings = { route = StillRoute.Settings },
            onRefreshApps = homeViewModel::refreshApps,
            onBack = { route = StillRoute.Home },
        )

        StillRoute.Settings -> SettingsScreen(
            uiState = uiState,
            onChooseSlot = { index ->
                val resolved = uiState.resolvedSlots.getOrNull(index)
                route = if (resolved?.isLaunchable == true) {
                    StillRoute.SlotEdit(index, ReturnTo.Settings)
                } else {
                    StillRoute.AppPicker(index, ReturnTo.Settings)
                }
            },
            onChangeSlotCount = homeViewModel::setSlotCount,
            onCycleClockFormat = {
                val next = when (uiState.settings.clockFormat) {
                    ClockFormat.Auto -> ClockFormat.Hours12
                    ClockFormat.Hours12 -> ClockFormat.Hours24
                    ClockFormat.Hours24 -> ClockFormat.Auto
                }
                homeViewModel.setClockFormat(next)
            },
            onToggleShowDate = {
                homeViewModel.setShowDate(!uiState.settings.showDate)
            },
            onToggleShowHomeHint = {
                homeViewModel.setShowHomeHint(!uiState.settings.showHomeHint)
            },
            onToggleShowAppIcons = {
                homeViewModel.setShowAppIcons(!uiState.settings.showAppIcons)
            },
            onCycleFontPreset = {
                val next = when (uiState.settings.fontPreset) {
                    FontPreset.System -> FontPreset.Editorial
                    FontPreset.Editorial -> FontPreset.Terminal
                    FontPreset.Terminal -> FontPreset.Grotesk
                    FontPreset.Grotesk -> FontPreset.System
                }
                homeViewModel.setFontPreset(next)
            },
            onToggleHaptics = {
                homeViewModel.setHapticsEnabled(!uiState.settings.hapticsEnabled)
            },
            onCycleDrawerFrictionMode = homeViewModel::cycleDrawerFrictionMode,
            onOpenDrawerExceptions = {
                route = StillRoute.DrawerExceptions(ReturnTo.Settings)
            },
            onOpenIntents = { route = StillRoute.Intents(ReturnTo.Settings) },
            onBack = { route = StillRoute.AllApps },
        )

        is StillRoute.AppPicker -> AppPickerScreen(
            slotIndex = currentRoute.slotIndex,
            apps = uiState.apps,
            selectedApp = uiState.resolvedSlots.getOrNull(currentRoute.slotIndex)?.app,
            showAppIcons = uiState.settings.showAppIcons,
            onAppSelected = { app ->
                homeViewModel.setSlotApp(currentRoute.slotIndex, app)
                route = currentRoute.returnTo.asRoute()
            },
            onBack = { route = currentRoute.returnTo.asRoute() },
        )

        is StillRoute.SlotEdit -> {
            val resolved = uiState.resolvedSlots.getOrNull(currentRoute.slotIndex)
            if (resolved == null || !resolved.isLaunchable) {
                route = currentRoute.returnTo.asRoute()
            } else {
                SlotEditScreen(
                    resolved = resolved,
                    isSystemSettings = uiState.isSystemSettings(resolved),
                    onRename = {
                        route = StillRoute.SlotRename(currentRoute.slotIndex, currentRoute.returnTo)
                    },
                    onReplaceApp = {
                        route = StillRoute.AppPicker(currentRoute.slotIndex, currentRoute.returnTo)
                    },
                    onToggleFriction = {
                        homeViewModel.setSlotFriction(
                            currentRoute.slotIndex,
                            !resolved.slot.useFriction,
                        )
                    },
                    onRemove = {
                        homeViewModel.clearSlot(currentRoute.slotIndex)
                        route = currentRoute.returnTo.asRoute()
                    },
                    onBack = { route = currentRoute.returnTo.asRoute() },
                )
            }
        }

        is StillRoute.SlotRename -> {
            val resolved = uiState.resolvedSlots.getOrNull(currentRoute.slotIndex)
            SlotRenameScreen(
                app = resolved?.app,
                initialLabel = resolved?.slot?.customLabel,
                onSave = { label ->
                    homeViewModel.setSlotLabel(currentRoute.slotIndex, label)
                    route = currentRoute.returnTo.asRoute()
                },
                onClearLabel = {
                    homeViewModel.setSlotLabel(currentRoute.slotIndex, null)
                    route = currentRoute.returnTo.asRoute()
                },
                onBack = {
                    route = StillRoute.SlotEdit(currentRoute.slotIndex, currentRoute.returnTo)
                },
            )
        }

        is StillRoute.IntentPrompt -> {
            val resolved = uiState.resolvedSlots.getOrNull(currentRoute.slotIndex)
            IntentPromptScreen(
                slotLabel = resolved?.displayLabel ?: "open",
                onOpen = { intent ->
                    homeViewModel.launchSlotWithIntent(currentRoute.slotIndex, intent)
                    route = StillRoute.Home
                },
                onCancel = { route = StillRoute.Home },
            )
        }

        is StillRoute.IntentPromptApp -> {
            val app = uiState.apps.firstOrNull {
                it.packageName == currentRoute.packageName && it.className == currentRoute.className
            }
            if (app == null) {
                route = StillRoute.AllApps
            } else {
                IntentPromptScreen(
                    slotLabel = currentRoute.label,
                    onOpen = { intent ->
                        homeViewModel.launchAppWithIntent(app, intent)
                        route = StillRoute.Home
                    },
                    onCancel = { route = StillRoute.Home },
                )
            }
        }

        is StillRoute.DrawerExceptions -> DrawerExceptionsScreen(
            apps = uiState.apps,
            mode = uiState.settings.drawerFrictionMode,
            exceptions = uiState.settings.drawerFrictionExceptions,
            onToggleException = homeViewModel::toggleDrawerFrictionException,
            onBack = { route = currentRoute.returnTo.asRoute() },
        )

        StillRoute.MomentDashboard -> MomentDashboardScreen(
            entries = momentEntries,
            onBack = { route = StillRoute.Home },
            onNewEntry = { route = StillRoute.MomentEditor(LocalDate.now(), MomentReturnTo.Dashboard) },
            onEditEntry = { day -> route = StillRoute.MomentEditor(day, MomentReturnTo.Dashboard) },
            onOpenCalendar = { route = StillRoute.MomentCalendar },
            onOpenStats = { route = StillRoute.MomentStats },
            onOpenReminder = { route = StillRoute.MomentReminder },
        )

        is StillRoute.MomentEditor -> MomentEditorScreen(
            date = currentRoute.date,
            existing = momentEntries.firstOrNull { it.day == currentRoute.date },
            onBack = { route = currentRoute.returnTo.asRoute() },
            onSave = { value ->
                momentRepository.save(currentRoute.date, value)
                route = currentRoute.returnTo.asRoute()
            },
            onDelete = {
                momentRepository.delete(currentRoute.date)
                route = currentRoute.returnTo.asRoute()
            },
        )

        StillRoute.MomentCalendar -> MomentCalendarScreen(
            entries = momentEntries,
            onBack = { route = StillRoute.MomentDashboard },
            onSelectDate = { day -> route = StillRoute.MomentEditor(day, MomentReturnTo.Dashboard) },
        )

        StillRoute.MomentStats -> MomentStatsScreen(
            entries = momentEntries,
            onBack = { route = StillRoute.MomentDashboard },
        )

        StillRoute.MomentReminder -> MomentReminderScreen(
            settings = reminderSettings,
            onBack = { route = StillRoute.MomentDashboard },
            onSetEnabled = { enabled ->
                reminderSettings = reminderPreferences.setEnabled(enabled)
            },
            onSetTime = { hour, minute ->
                reminderSettings = reminderPreferences.setTime(hour, minute)
            },
        )

        is StillRoute.Intents -> IntentsScreen(
            entries = intentEntries,
            onClear = homeViewModel::clearJournal,
            onBack = { route = currentRoute.returnTo.asRoute() },
        )
    }
    }
}

private enum class ReturnTo {
    Home, Settings;

    fun asRoute(): StillRoute = when (this) {
        Home -> StillRoute.Home
        Settings -> StillRoute.Settings
    }
}

private enum class MomentReturnTo {
    Home, Dashboard;
    fun asRoute(): StillRoute = when (this) {
        Home -> StillRoute.Home
        Dashboard -> StillRoute.MomentDashboard
    }
}

private sealed interface StillRoute {
    data object Home : StillRoute
    data object AllApps : StillRoute
    data object Settings : StillRoute
    data class AppPicker(val slotIndex: Int, val returnTo: ReturnTo) : StillRoute
    data class SlotEdit(val slotIndex: Int, val returnTo: ReturnTo) : StillRoute
    data class SlotRename(val slotIndex: Int, val returnTo: ReturnTo) : StillRoute
    data class IntentPrompt(val slotIndex: Int) : StillRoute
    data class IntentPromptApp(
        val packageName: String,
        val className: String,
        val label: String,
    ) : StillRoute
    data class DrawerExceptions(val returnTo: ReturnTo) : StillRoute
    data class Intents(val returnTo: ReturnTo) : StillRoute
    data object MomentDashboard : StillRoute
    data class MomentEditor(val date: LocalDate, val returnTo: MomentReturnTo) : StillRoute
    data object MomentCalendar : StillRoute
    data object MomentStats : StillRoute
    data object MomentReminder : StillRoute
}

private fun StillRoute.backTarget(): StillRoute = when (this) {
    StillRoute.Home -> StillRoute.Home
    StillRoute.AllApps -> StillRoute.Home
    StillRoute.Settings -> StillRoute.AllApps
    is StillRoute.AppPicker -> returnTo.asRoute()
    is StillRoute.SlotEdit -> returnTo.asRoute()
    is StillRoute.SlotRename -> StillRoute.SlotEdit(slotIndex, returnTo)
    is StillRoute.IntentPrompt -> StillRoute.Home
    is StillRoute.IntentPromptApp -> StillRoute.AllApps
    is StillRoute.DrawerExceptions -> returnTo.asRoute()
    is StillRoute.Intents -> returnTo.asRoute()
    StillRoute.MomentDashboard -> StillRoute.Home
    is StillRoute.MomentEditor -> returnTo.asRoute()
    StillRoute.MomentCalendar -> StillRoute.MomentDashboard
    StillRoute.MomentStats -> StillRoute.MomentDashboard
    StillRoute.MomentReminder -> StillRoute.MomentDashboard
}


private fun momentCurrentStreak(entries: List<dev.chuds.still.moments.MomentEntry>): Int {
    val days = entries.map { it.day }.toSet()
    val today = LocalDate.now()
    var cursor = if (today in days) today else today.minusDays(1)
    var count = 0
    while (cursor in days) {
        count++
        cursor = cursor.minusDays(1)
    }
    return count
}
