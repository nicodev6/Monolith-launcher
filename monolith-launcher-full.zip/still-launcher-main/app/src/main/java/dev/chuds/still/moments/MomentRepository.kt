package dev.chuds.still.moments

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

/** One private reflection per calendar day. Data stays on-device in the app's SQLite database. */
data class MomentEntry(
    val day: LocalDate,
    val text: String,
    val createdAt: Long,
    val updatedAt: Long,
)

class MomentRepository(context: Context) {
    private val helper = MomentDatabase(context.applicationContext)
    private val mutableEntries = MutableStateFlow(loadAll())
    val entries: StateFlow<List<MomentEntry>> = mutableEntries.asStateFlow()

    @Synchronized
    fun save(day: LocalDate, text: String): Boolean {
        val cleaned = text.trim().take(MAX_MOMENT_LENGTH)
        if (cleaned.isBlank()) return false
        val now = System.currentTimeMillis()
        val existing = mutableEntries.value.firstOrNull { it.day == day }
        val values = ContentValues().apply {
            put("day_key", day.toEpochDay())
            put("body", cleaned)
            put("created_at", existing?.createdAt ?: now)
            put("updated_at", now)
        }
        val result = helper.writableDatabase.insertWithOnConflict(
            "moments", null, values, SQLiteDatabase.CONFLICT_REPLACE,
        )
        refresh()
        return result != -1L
    }

    @Synchronized
    fun delete(day: LocalDate) {
        helper.writableDatabase.delete("moments", "day_key = ?", arrayOf(day.toEpochDay().toString()))
        refresh()
    }

    @Synchronized
    fun refresh() {
        mutableEntries.value = loadAll()
    }

    private fun loadAll(): List<MomentEntry> {
        val result = mutableListOf<MomentEntry>()
        val cursor = helper.readableDatabase.query(
            "moments",
            arrayOf("day_key", "body", "created_at", "updated_at"),
            null, null, null, null,
            "day_key DESC",
        )
        cursor.use {
            while (it.moveToNext()) {
                result += MomentEntry(
                    day = LocalDate.ofEpochDay(it.getLong(0)),
                    text = it.getString(1),
                    createdAt = it.getLong(2),
                    updatedAt = it.getLong(3),
                )
            }
        }
        return result
    }

    companion object {
        const val MAX_MOMENT_LENGTH = 150
    }
}

private class MomentDatabase(context: Context) : SQLiteOpenHelper(
    context,
    "monolith_moments.db",
    null,
    1,
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE moments (
                day_key INTEGER NOT NULL PRIMARY KEY,
                body TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )""".trimIndent(),
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 is the initial on-device schema. Future migrations must preserve entries.
    }
}
