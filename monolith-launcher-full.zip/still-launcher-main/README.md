<div align="center">

# MONOLITH

#### A quiet Android launcher with a private daily reflection journal.

part of the [still](STILL.md) family. the pact governs every line of code in this repo.

<br>
</div>

---

MONOLITH is a minimalist, privacy-first Android launcher built on the STILL codebase. It is monochrome, OLED-first, text-first, and designed to make a modern Android phone feel closer to a beautiful dumb phone.

It declares no internet permission. It ships no analytics. It depends on neither Firebase nor Google Play Services. It targets a Pixel running GrapheneOS, but it runs on any Android device from API 26 up.

## What MONOLITH does

- Replaces the home screen with the MONOLITH wordmark, an oversized clock, the date, a daily reflection card, and your configured app slots.
- **Sane first-launch defaults**: Phone, Messaging, Browser, Camera, Calendar, Settings, resolved from system intents. Each slot is yours to rename, replace, or remove.
- Each slot opens an app you choose, with a label you choose. Mappings persist locally in Preferences DataStore.
- Any slot can be marked **use intentionally** — tapping it opens an intent prompt (*Use this intentionally. what for?*) before launching. Type a sentence, press Done, and the app opens. (Settings is exempt — it's the escape hatch and must always be one tap away.)
- An **intent journal** records what you typed every time you launched something through the prompt. Tap the date on the home screen to read back through it. Still doesn't block anything; it just remembers what you said you'd do.
- **Configurable**: slot count (1–10), 12/24-hour clock, date toggle, home-hint toggle, per-slot friction. Every choice is yours to make.
- **Jeden Moment**: one private reflection per day, saved locally in SQLite, limited to 150 characters, editable later, and accessible from the home-screen card.
- **Moment history**: month-by-month calendar with saved days highlighted, recent entries, daily and longest-streak statistics.
- **Daily reminder**: configurable reminder time using Android notifications and a daily local-time inexact alarm. Android 13+ asks for notification permission.
- Long-press the home background to reveal the all-apps list and settings.

## Jeden Moment

The daily reflection system is separate from the existing app-launch intent journal. One entry is stored per calendar day. The editor allows up to 150 characters and supports updates and deletion. The calendar opens historical days, while statistics report total saved days, the current streak, the longest streak, and this month's entries. Data is stored in the app-private SQLite database and excluded from Android backup and device transfer.

The optional reminder is scheduled locally. The app does not need internet access, an account, or Google Play Services. Android may defer inexact alarms to save battery, and notifications only appear when the user grants notification permission.

## The intent journal

Still doesn't restrict you from using apps. It can't, and it shouldn't. What it can do is hand the question back to you: *what is this for?*

Mark a slot **use intentionally**. The next time you tap it, Still asks what you're opening it for. You type a sentence — anything — and it opens. The text is journaled locally, alongside the slot label and a timestamp. Days later, you tap the date on the home screen and read through the list.

Reading the journal is the whole mechanism. The launcher is not the conscience. You are.

The journal lives entirely on-device in a separate Preferences DataStore (`still_journal`). The most recent 500 entries are kept. Cleared with two taps in the journal screen. Excluded from cloud backup and device transfer.

## Privacy posture

- No `INTERNET` permission.
- No `QUERY_ALL_PACKAGES`. Package visibility is scoped to launcher/default-intent `<queries>` only.
- No Firebase, Google Play Services dependency, ads, or cloud sync.
- Settings, both journals, and reminders stay local. Android backup and device transfer are disabled.
- No notification listener or accessibility service.

## Privacy posture, in code

| File | What it guarantees |
| --- | --- |
| `app/src/main/AndroidManifest.xml` | Only notification and boot-reschedule permissions; app discovery remains scoped to launcher/default-intent visibility |
| `app/src/main/res/xml/data_extraction_rules.xml` | Excludes every sharedpref / file / database domain from cloud backup and device transfer |
| `app/build.gradle.kts` | AndroidX, Compose, and DataStore only; no Firebase, GMS, or analytics SDK |

## Architecture

```text
MainActivity
└── StillApp                          single-Activity Compose shell
    ├── HomeViewModel
    │   ├── AppRepository
    │   │   ├── PackageScanner        ACTION_MAIN + CATEGORY_LAUNCHER, scoped
    │   │   └── PreferencesRepository slot config + launcher prefs
    │   ├── IntentJournalRepository   separate DataStore, JSON-encoded entries
    │   └── AppLauncher               explicit component launches only
    └── Compose surfaces
        ├── HomeScreen                MONOLITH clock, daily reflection card, and app slots
        ├── IntentPromptScreen        "Use this intentionally. what for?"
        ├── IntentsScreen             reverse-chrono app-launch journal
        ├── MomentDashboardScreen     daily reflection dashboard + recent entries
        ├── MomentEditorScreen        one 150-character entry per day
        ├── MomentCalendarScreen      month calendar and history
        ├── MomentStatsScreen         saved-day and streak statistics
        └── MomentReminderScreen      configurable daily notification
        ├── SlotEditScreen            long-press a filled slot
        ├── SlotRenameScreen          custom labels per slot
        ├── AppPickerScreen           list of launchable apps
        ├── AllAppsScreen             revealed by long-press on background
        └── SettingsScreen            launcher prefs, slots, journal
```

Kotlin, Jetpack Compose, AGP 9, Gradle Kotlin DSL. Slots are anonymous indices `0..9` — there is no enum mapping to specific app types. Navigation Compose is intentionally avoided; a small sealed-class router lives in `StillApp.kt`. Journal entries are encoded as JSON via `org.json` (no extra serialization dependency).

## Gestures

| Gesture | Effect |
| --- | --- |
| Tap a filled slot | Launch (or open the intent prompt, if the slot is gated) |
| Long-press a filled slot | Edit slot — rename, replace, toggle friction, remove |
| Long-press home background | Open all apps |
| Tap the date | Open the intent journal |
| Tap **Zapisz moment** | Open today's reflection editor |
| Tap **Historia momentów** | Open the reflection dashboard |

Slot count, clock format, and the date row itself are configured under **still settings → launcher**.

## Design language

- OLED black background, soft white text, muted gray secondary labels, and a warm cream action color.
- Serif or editorial clock typography, sans-serif content, and monospaced section labels.
- Rounded dark reflection panel and compact app shortcuts, matching the MONOLITH concept.
- No ripple or unnecessary motion; preserve the existing STILL launcher configuration and app-slot behavior.

## Build and install

Requirements: **JDK 17**, the **Android SDK** with `platforms;android-36` and `build-tools;36.0.0`. The Gradle wrapper (9.4.1) is bundled.

```bash
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Then, on the device: **Settings → Apps → Default apps → Home app → Still**.

For development on an emulator, set Still as the default Home directly:

```bash
adb shell cmd package set-home-activity dev.chuds.still/.MainActivity
```

## Notes for GrapheneOS

Still depends on no part of Google Play Services, so it runs cleanly on a fresh GrapheneOS profile. On first launch it resolves the canonical system apps for Phone, Messaging, Browser, Camera, Calendar, and Settings via standard category intents and seeds the slot list — categories that don't resolve (e.g. no preinstalled browser) leave their slots empty for you to fill.

## Status

The MONOLITH home and the Jeden Moment feature set are implemented in source. Build verification was not possible in the current editing environment because the Gradle distribution could not be downloaded. Run the build and test steps below in Android Studio or on a machine with the Android SDK and Gradle distribution available before installing to a device.

## License

MIT. See [`LICENSE`](LICENSE).
